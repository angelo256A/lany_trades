const $=id=>document.getElementById(id);
let accounts=[], ws=null, analyzer=null, req=1000, proposal=null, contractId=null;
let bot={running:false,trades:0,wins:0,losses:0,pl:0,consecutiveLosses:0,dailyLoss:0,history:[],stake:1};

class TickAnalyzer{
 constructor(limit=100){this.limit=limit;this.digits=[];this.ws=null}
 setLimit(n){this.limit=Number(n);this.digits=this.digits.slice(-this.limit)}
 addQuote(q){const s=String(q), clean=s.replace(/[^0-9]/g,"");if(!clean)return null;const d=Number(clean.at(-1));this.digits.push(d);if(this.digits.length>this.limit)this.digits.shift();return d}
 counts(){const c=Array(10).fill(0);this.digits.forEach(d=>c[d]++);return c}
 total(){return this.digits.length}
}
function setNotice(t){$("notice").textContent=t}
function updateBotUI(){$("botState").textContent=bot.running?"RUNNING":"STOPPED";$("botState").className=bot.running?"green":"amber";$("trades").textContent=bot.trades;$("wins").textContent=bot.wins;$("losses").textContent=bot.losses;$("pl").textContent=bot.pl.toFixed(2);$("botStatus").textContent=bot.running?`Running · stake ${bot.stake}`:"Bot stopped."}
async function load(){
 const s=await fetch("/api/session").then(r=>r.json()); if(!s.authenticated){location.href="/";return}
 const r=await fetch("/api/accounts"), d=await r.json(); accounts=d.data||d.accounts||[];
 const sel=$("account");sel.innerHTML="";
 accounts.forEach(a=>{const o=document.createElement("option");o.value=a.account_id||a.id;o.textContent=(a.account_id||a.id)+" · "+(a.currency||"");o.dataset.type=a.is_demo?"Demo":"Real";sel.appendChild(o)});
 if(accounts.length){updateType();await balance()}
 setNotice(accounts.length+" Deriv account(s) connected.");
 connectTicks();
}
async function balance(){const id=$("account").value;if(!id)return;const r=await fetch("/api/balance",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({accountId:id})});const d=await r.json();const b=d.balance||d.data?.balance;$("balance").textContent=b?.balance!=null?`${b.balance} ${b.currency||""}`:"Unavailable"}
function updateType(){$("type").textContent=$("account").selectedOptions[0]?.dataset.type||"-"}
function connectTicks(){
 if(analyzer?.ws)try{analyzer.ws.close()}catch{}
 analyzer=new TickAnalyzer(Number($("window").value));
 const t=new WebSocket("wss://api.derivws.com/trading/v1/options/ws/public");
 analyzer.ws=t;
 t.onopen=()=>t.send(JSON.stringify({ticks:$("tradeSymbol").value,subscribe:1,req_id:1}));
 t.onmessage=e=>{try{const d=JSON.parse(e.data);if(d.msg_type==="tick")handleTick(d.tick)}catch{}};
 t.onclose=()=>setTimeout(connectTicks,2000);
}
function handleTick(t){
 const d=analyzer.addQuote(t.quote);$("lastDigit").textContent=d??"-";$("ticks").textContent=analyzer.total();renderAnalysis();
}
function renderAnalysis(){
 const c=analyzer.counts(),n=analyzer.total(),max=Math.max(1,...c);
 const hot=n?c.indexOf(Math.max(...c)):"-", cold=n?c.indexOf(Math.min(...c)):"-";
 $("hot").textContent=hot;$("cold").textContent=cold;
 $("over0").textContent=n?((n-c[0])/n*100).toFixed(1)+"%":"-";
 $("under9").textContent=n?((n-c[9])/n*100).toFixed(1)+"%":"-";
 const bars=$("bars");bars.innerHTML="";
 c.forEach((x,i)=>{const el=document.createElement("div");el.className="barItem";el.innerHTML=`<b>${n?(x/n*100).toFixed(0):0}%</b><div class="bar" style="height:${Math.max(2,x/max*90)}px"></div><span>${i}</span>`;bars.appendChild(el)});
 const sig=getSignal();
 $("recommendation").textContent=sig.action;$("edge").textContent=sig.edge.toFixed(1)+"%";$("reason").textContent=sig.reason;
 $("signal").textContent=n<20?"Collecting ticks…":`${sig.action} · ${sig.reason}`;$("signal").className="signal "+(sig.action==="WAIT"?"neutral":"positive");
 if(bot.running && sig.action!=="WAIT") maybeTrade(sig);
}
function getSignal(){
 const n=analyzer.total(),c=analyzer.counts(),min=Number($("minEdge").value||15),strategy=$("strategy").value,target=Number($("targetDigit").value);
 if(n<20)return {action:"WAIT",edge:0,reason:"Need at least 20 ticks"};
 if(strategy==="DIGIT_BIAS"){const p=c[target]/n*100;return p>=min?{action:"MATCH",edge:p,reason:`Digit ${target} frequency ${p.toFixed(1)}%`}:{action:"WAIT",edge:p,reason:`Digit ${target} only ${p.toFixed(1)}%`}}
 if(strategy==="OVER_UNDER"){const over=(n-c[0])/n*100,under=(n-c[9])/n*100;if(over>=min&&over>under)return {action:"OVER_0",edge:over,reason:`Over 0 observed ${over.toFixed(1)}%`};if(under>=min&&under>over)return {action:"UNDER_9",edge:under,reason:`Under 9 observed ${under.toFixed(1)}%`};return {action:"WAIT",edge:Math.max(over,under),reason:"No clear edge"}}
 const match=Math.max(...c)/n*100;const differ=100-match;
 if(match>=min&&match>differ)return {action:"MATCH",edge:match,reason:"Highest digit frequency selected"};
 if(differ>=min)return {action:"DIFFER",edge:differ,reason:"Differ probability exceeds threshold"};
 return {action:"WAIT",edge:Math.max(match,differ),reason:"No clear edge"};
}
async function getWs(){
 if(ws&&ws.readyState===1)return;
 const r=await fetch("/api/trading/ws-url",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({accountId:$("account").value})});
 const d=await r.json();if(!r.ok)throw new Error(d.error||"WS auth failed");
 ws=new WebSocket(d.url);ws.onmessage=e=>handleTrade(JSON.parse(e.data));
 await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject});
}
function send(o){o.req_id=++req;ws.send(JSON.stringify(o))}
function handleTrade(d){
 if(d.error){$("botStatus").textContent="Deriv error: "+(d.error.message||d.error.code);return}
 if(d.msg_type==="proposal"){proposal=d.proposal}
 if(d.msg_type==="buy"){contractId=d.buy.contract_id;send({proposal_open_contract:1,contract_id:contractId,subscribe:1})}
 if(d.msg_type==="proposal_open_contract"){
   const c=d.proposal_open_contract;
   if(c.is_sold||["won","lost","sold","expired"].includes(c.status))finishTrade(c);
 }
}
async function maybeTrade(sig){
 if(!bot.running||proposal||contractId)return;
 if(bot.consecutiveLosses>=Number($("maxLosses").value)||bot.dailyLoss>=Number($("dailyLoss").value)){stopBot("Risk limit reached.");return}
 const stake=Math.min(Number($("stake").value),Number($("maxStake").value));
 bot.stake=stake;
 // Phase 4 executes a conservative DEMO multiplier trade from the directional signal.
 // Digit-specific contract execution is deliberately left for the contract-availability adapter.
 if(sig.action!=="OVER_0"&&sig.action!=="UNDER_9")return;
 try{
  await getWs();
  const ct=sig.action==="OVER_0"?"MULTUP":"MULTDOWN";
  send({proposal:1,amount:stake,basis:"stake",contract_type:ct,currency:"USD",duration:1,duration_unit:"m",multiplier:10,underlying_symbol:$("tradeSymbol").value,subscribe:1});
  setTimeout(()=>{if(proposal&&!contractId){send({buy:String(proposal.id),price:stake});proposal=null}},800);
 }catch(e){$("botStatus").textContent="Bot connection error."}
}
function finishTrade(c){
 const profit=Number(c.profit||0);bot.trades++;bot.pl+=profit;
 if(profit>0){bot.wins++;bot.consecutiveLosses=0}else{bot.losses++;bot.consecutiveLosses++;bot.dailyLoss+=Math.max(0,-profit)}
 bot.history.unshift({time:new Date().toLocaleTimeString(),status:profit>0?"WIN":"LOSS",profit});
 bot.history=bot.history.slice(0,10);contractId=null;proposal=null;renderHistory();updateBotUI();
 if(bot.running)setTimeout(()=>renderAnalysis(),500);
}
function renderHistory(){$("history").innerHTML=bot.history.length?bot.history.map(x=>`<div class="hist"><span>${x.time} · ${x.status}</span><b>${x.profit.toFixed(2)}</b></div>`).join(""):"No trades yet."}
function stopBot(msg="Bot stopped."){bot.running=false;$("botStatus").textContent=msg;updateBotUI()}
$("window").addEventListener("change",()=>{analyzer.setLimit(Number($("window").value));renderAnalysis()});
$("tradeSymbol").addEventListener("change",connectTicks);
$("strategy").addEventListener("change",renderAnalysis);$("minEdge").addEventListener("input",renderAnalysis);$("targetDigit").addEventListener("input",renderAnalysis);
$("startBot").addEventListener("click",()=>{if($("type").textContent!=="Demo"){alert("Select a DEMO account before starting the bot.");return}bot.running=true;bot.dailyLoss=0;bot.consecutiveLosses=0;bot.stake=Number($("stake").value);updateBotUI();renderAnalysis()});
$("stopBot").addEventListener("click",()=>stopBot());
$("account").addEventListener("change",()=>{updateType();balance();stopBot()});
$("logout").addEventListener("click",async()=>{stopBot();await fetch("/auth/logout",{method:"POST"});location.href="/"});
load();

async function checkInternet(){
  try{
    const r=await fetch("/api/health");
    const d=await r.json();
    $("internet").textContent=d.online?"● Internet + Deriv API online":"● Deriv API unavailable";
    $("internet").className="internet "+(d.online?"online":"offline");
  }catch{
    $("internet").textContent="● Internet unavailable";
    $("internet").className="internet offline";
  }
}
checkInternet(); setInterval(checkInternet,30000);
