# LANY TRADES — Phase 2

Phase 2 adds a secure Deriv OAuth 2.0 login scaffold and an authenticated account dashboard.

## What it does
- Redirects users to Deriv for login/consent.
- Uses OAuth 2.0 Authorization Code + PKCE.
- Keeps the OAuth access token server-side in the session.
- Lists Options trading accounts.
- Generates a short-lived authenticated WebSocket URL through Deriv's OTP endpoint.
- Reads the selected account balance.
- Does NOT place trades.

## Setup
1. Register an OAuth2 application with Deriv and obtain its client ID.
2. Register the exact callback URL you will use, e.g. `http://localhost:3000/callback` for local testing.
3. Copy `.env.example` to `.env`.
4. Set `DERIV_CLIENT_ID`, `REDIRECT_URI`, and a long `SESSION_SECRET`.
5. Run `npm install`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

For production, use HTTPS, a persistent session store, proper secrets management, and a registered production redirect URI.

## Security
Do not put Deriv access tokens in frontend JavaScript. The OAuth code exchange is performed by the backend. Request only the OAuth scopes the product actually needs.


## Phase 3
Phase 3 adds:
- authenticated trading WebSocket URL retrieval
- proposal requests
- DEMO-only buy control
- open-contract monitoring
- market sell control
- basic stake/open-trade/daily-loss guardrail fields
- explicit confirmation before demo buy/sell

Real-account execution is disabled in the UI. The server exposes only the authenticated WebSocket URL endpoint; trading messages are sent from the dashboard over the authenticated session. This follows Deriv's current workflow: obtain an OTP URL via REST, connect to the demo/real WebSocket it returns, request a proposal, buy, then monitor `proposal_open_contract`; selling uses `sell`. See Deriv's trading workflow and trading endpoint documentation.


## Phase 4 — Analyzer → Signal Engine → Demo Bot

Phase 4 adds:
- live tick digit analyzer
- 50/100/120/200/500 tick windows
- Digit Bias, Over/Under, and Matches/Differs signal modes
- minimum-edge threshold
- demo-only automated execution
- stake cap
- consecutive-loss stop
- daily-loss stop
- session win/loss/P&L tracking
- recent trade history

### Safety/strategy note
The automated executor is deliberately conservative. The current adapter maps only the Over/Under directional signals to a demo multiplier contract (`MULTUP`/`MULTDOWN`). The UI does not enable real-account automation, and no martingale/recovery sizing is enabled.

Deriv's current API supports proposal → buy → proposal_open_contract → sell workflows. The current API also uses `underlying_symbol` and has removed legacy `loginid` from these requests. The Phase 4 code follows that newer parameter naming.


## Combined build
This archive combines Phases 1–4 into one Node/Express project. It is designed to run with Internet access:
- public Deriv market WebSocket for live ticks
- Deriv REST API for OAuth/account/OTP operations
- authenticated Deriv WebSocket for demo trading
- `/api/health` checks Internet/Deriv API availability

### Run
1. Extract the archive.
2. Install Node.js 18+.
3. Copy `.env.example` to `.env`.
4. Add your Deriv OAuth Client ID, exact callback URL, and a strong session secret.
5. `npm install`
6. `npm start`
7. Open the displayed local address.

The server must be running on a machine with Internet access. A browser alone cannot run the OAuth/token backend securely.
