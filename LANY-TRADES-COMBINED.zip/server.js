import express from "express";
import session from "express-session";
import crypto from "crypto";
import { WebSocket } from "ws";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const CLIENT_ID = process.env.DERIV_CLIENT_ID || "";
const REDIRECT_URI = process.env.REDIRECT_URI || `http://localhost:${PORT}/callback`;

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE_ME",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 60*60*1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function b64url(buf){return Buffer.from(buf).toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");}
function randomString(n=64){return b64url(crypto.randomBytes(n));}
function challenge(verifier){return crypto.createHash("sha256").update(verifier).digest("base64url");}

app.get("/auth/deriv", (req,res)=>{
  if(!CLIENT_ID) return res.status(500).send("Set DERIV_CLIENT_ID in .env before connecting Deriv.");
  const state=randomString(24), verifier=randomString(48);
  req.session.oauthState=state;
  req.session.codeVerifier=verifier;
  const u=new URL("https://auth.deriv.com/oauth2/auth");
  u.searchParams.set("response_type","code");
  u.searchParams.set("client_id",CLIENT_ID);
  u.searchParams.set("redirect_uri",REDIRECT_URI);
  u.searchParams.set("scope","trade");
  u.searchParams.set("state",state);
  u.searchParams.set("code_challenge",challenge(verifier));
  u.searchParams.set("code_challenge_method","S256");
  res.redirect(u.toString());
});

app.get("/callback", async (req,res)=>{
  try{
    if(req.query.error) return res.status(400).send(`Deriv login cancelled: ${req.query.error_description || req.query.error}`);
    if(!req.query.code || !req.query.state || req.query.state !== req.session.oauthState) return res.status(400).send("Invalid OAuth state.");
    const body=new URLSearchParams({
      grant_type:"authorization_code",
      client_id:CLIENT_ID,
      code:req.query.code,
      code_verifier:req.session.codeVerifier,
      redirect_uri:REDIRECT_URI
    });
    const r=await fetch("https://auth.deriv.com/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
    const data=await r.json();
    if(!r.ok || !data.access_token) return res.status(502).json(data);
    req.session.accessToken=data.access_token;
    req.session.expiresAt=Date.now()+Number(data.expires_in||3600)*1000;
    delete req.session.oauthState; delete req.session.codeVerifier;
    res.redirect("/dashboard.html");
  }catch(e){res.status(500).send("OAuth callback failed.");}
});

function requireAuth(req,res,next){
  if(!req.session.accessToken) return res.status(401).json({error:"not_authenticated"});
  next();
}

async function derivFetch(req, url, options={}){
  const headers={...(options.headers||{}),Authorization:`Bearer ${req.session.accessToken}`,"Deriv-App-ID":CLIENT_ID,"Content-Type":"application/json"};
  return fetch(url,{...options,headers});
}

app.get("/api/health",async(req,res)=>{
  try{
    const r=await fetch("https://api.derivws.com/health");
    const data=await r.json().catch(()=>({}));
    res.status(r.ok?200:502).json({online:r.ok,deriv:data});
  }catch(e){res.status(502).json({online:false,error:"internet_or_deriv_unreachable"});}
});

app.get("/api/session",(req,res)=>{
  res.json({authenticated:!!req.session.accessToken,expiresAt:req.session.expiresAt||null});
});

app.get("/api/accounts",requireAuth,async(req,res)=>{
  try{
    const r=await derivFetch(req,"https://api.derivws.com/trading/v1/options/accounts");
    const data=await r.json();
    res.status(r.status).json(data);
  }catch(e){res.status(502).json({error:"deriv_unreachable"});}
});

app.post("/api/otp",requireAuth,async(req,res)=>{
  const accountId=String(req.body.accountId||"");
  if(!/^[A-Z0-9]+$/.test(accountId)) return res.status(400).json({error:"invalid_account_id"});
  try{
    const r=await derivFetch(req,`https://api.derivws.com/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`,{method:"POST"});
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json(data);
    res.json({url:data?.data?.url||null});
  }catch(e){res.status(502).json({error:"otp_failed"});}
});

app.post("/api/balance",requireAuth,async(req,res)=>{
  const accountId=String(req.body.accountId||"");
  if(!accountId) return res.status(400).json({error:"account_id_required"});
  try{
    const r=await derivFetch(req,`https://api.derivws.com/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`,{method:"POST"});
    const otp=await r.json();
    if(!r.ok || !otp?.data?.url) return res.status(r.status||502).json(otp);
    const ws=new WebSocket(otp.data.url);
    const timer=setTimeout(()=>{try{ws.close()}catch{};res.status(504).json({error:"balance_timeout"})},10000);
    ws.on("message",raw=>{
      try{
        const msg=JSON.parse(raw.toString());
        if(msg.msg_type==="balance" || msg.balance){
          clearTimeout(timer); try{ws.close()}catch{}; res.json(msg); 
        }
        if(msg.error){
          clearTimeout(timer); try{ws.close()}catch{}; res.status(400).json(msg);
        }
      }catch{}
    });
    ws.on("open",()=>ws.send(JSON.stringify({balance:1,subscribe:1,req_id:1})));
    ws.on("error",()=>{clearTimeout(timer);res.status(502).json({error:"authenticated_websocket_error"});});
  }catch(e){res.status(502).json({error:"balance_failed"});}
});

app.post("/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/dashboard.html",requireAuth,(req,res)=>res.sendFile(path.join(__dirname,"public","dashboard.html")));


async function getAuthenticatedWs(req, accountId){
  const r=await derivFetch(req,`https://api.derivws.com/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`,{method:"POST"});
  const data=await r.json();
  if(!r.ok || !data?.data?.url) throw new Error("Could not obtain authenticated WebSocket URL");
  return data.data.url;
}

app.post("/api/trading/ws-url",requireAuth,async(req,res)=>{
  try{
    const accountId=String(req.body.accountId||"");
    if(!accountId) return res.status(400).json({error:"account_id_required"});
    const url=await getAuthenticatedWs(req,accountId);
    res.json({url});
  }catch(e){res.status(502).json({error:"ws_url_failed"});}
});

app.listen(PORT,()=>console.log(`LANY TRADES Phase 3 running at http://localhost:${PORT}`));